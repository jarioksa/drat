# BayesLogit-1
:exclamation: This is based on read-only mirror of the CRAN R package repository.  BayesLogit — Logistic Regression  

Except that this version will pass `R CMD check --as-cran` and could re-enter CRAN.
