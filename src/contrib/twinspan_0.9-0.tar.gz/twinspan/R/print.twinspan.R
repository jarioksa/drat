## print method for twinspan: not documented

#' @importFrom utils str
#' @export
`print.twinspan` <-
    function(x, ...)
{
    str(x, ...)
}
